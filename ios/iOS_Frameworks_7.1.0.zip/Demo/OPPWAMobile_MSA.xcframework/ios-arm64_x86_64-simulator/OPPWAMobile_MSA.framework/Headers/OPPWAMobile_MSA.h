//  © Copyright ACI Worldwide, Inc. 2018, 2025

#import <Foundation/Foundation.h>

//! Project version number for OPPWAMobile_MSA.
FOUNDATION_EXPORT double OPPWAMobile_MSAVersionNumber;

//! Project version string for OPPWAMobile_MSA.
FOUNDATION_EXPORT const unsigned char OPPWAMobile_MSAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OPPWAMobile_MSA/PublicHeader.h>


