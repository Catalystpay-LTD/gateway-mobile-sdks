package com.oppwa.mobile.connect.demo.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PersistableBundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.oppwa.mobile.connect.demo.R
import com.oppwa.mobile.connect.demo.adapter.VisaPlanAdapter
import com.oppwa.mobile.connect.demo.common.Constants
import com.oppwa.mobile.connect.demo.databinding.ActivityCustomUiBinding
import com.oppwa.mobile.connect.exception.PaymentError
import com.oppwa.mobile.connect.exception.PaymentException
import com.oppwa.mobile.connect.payment.CheckoutInfo
import com.oppwa.mobile.connect.payment.card.CardPaymentParams
import com.oppwa.mobile.connect.payment.fingerprint.CyberSourceDeviceFingerprint
import com.oppwa.mobile.connect.payment.fingerprint.FingerPrintListener
import com.oppwa.mobile.connect.payment.visainstallment.InstallmentPlansParams
import com.oppwa.mobile.connect.payment.visainstallment.VisaPlan
import com.oppwa.mobile.connect.provider.*
import com.oppwa.mobile.connect.utils.Logger
import com.oppwa.msa.model.response.CheckoutCreationResponse

import kotlinx.coroutines.ExperimentalCoroutinesApi

private const val STATE_RESOURCE_PATH = "STATE_RESOURCE_PATH"


/**
 * This activity represents the custom UI integration.
 */
class CustomUIActivity : BasePaymentActivity(), ITransactionListener {

    private lateinit var binding: ActivityCustomUiBinding

    private lateinit var checkoutId: String
    private var paymentProvider: OppPaymentProvider? = null
    private var resourcePath: String? = null
    private var installmentTransactionId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        resourcePath = savedInstanceState?.getString(STATE_RESOURCE_PATH)

        binding = ActivityCustomUiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        paymentProvider = OppPaymentProvider(this, Connect.ProviderMode.TEST)
        paymentProvider!!.setThreeDSWorkflowListener { this }

        initViews()
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)

        outState.putString(STATE_RESOURCE_PATH, resourcePath)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        setIntent(intent)

        // check of the intent contains the callback scheme
        if (intent.scheme == getString(R.string.custom_ui_callback_scheme)) {
            requestPaymentStatus(resourcePath!!)
        }
    }

    override fun onCheckoutCreated(response: CheckoutCreationResponse?) {
        super.onCheckoutCreated(response)

        response?.ndc.let {
            this.checkoutId = response?.ndc!!
            requestCheckoutInfo(checkoutId)
        }
    }

    override fun paymentConfigRequestSucceeded(checkoutInfo: CheckoutInfo) {
        // get the resource path from checkout info to request the payment status later
        resourcePath = checkoutInfo.resourcePath

        if (binding.switchVisaInstallment.isChecked && checkoutInfo.isVisaInstallmentEnabled) {
                fetchVisaPlans()
        } else {
            runOnUiThread {
                showConfirmationDialog(
                    checkoutInfo.amount.toString(),
                    checkoutInfo.currencyCode!!
                )
            }
        }
    }

    private fun fetchVisaPlans(){
        val params = InstallmentPlansParams(
            checkoutId,
            Constants.Config.CARD_BRAND,
            Constants.Config.VISA_INSTALLMENT_CARD_CVV,
            Constants.Config.VISA_INSTALLMENT_CARD_NUMBER,
            Constants.Config.VISA_INSTALLMENT_CARD_EXPIRY_MONTH,
            Constants.Config.VISA_INSTALLMENT_CARD_EXPIRY_YEAR,
            "John Doe"
        )

        paymentProvider?.requestVisaInstallmentPlans(params) { response, error ->
            if (error != null) {
                hideProgressBar()
                showErrorDialog(error.errorMessage)
                return@requestVisaInstallmentPlans
            }

            if (response != null) {
                installmentTransactionId = response.id
            }

            response?.installmentOffers?.let { offers ->
                runOnUiThread {
                    setDataToVisaAdapter(offers)
                }
            }
            hideProgressBar()
        }
    }

    private fun setDataToVisaAdapter(listOfPlans: List<VisaPlan>) {
        val bottomSheetView = layoutInflater.inflate(R.layout.bottom_sheet_visa_plans,
            findViewById(android.R.id.content), false)
        val recyclerView = bottomSheetView.findViewById<RecyclerView>(R.id.visaPlansRecyclerView)
        val buttonConfirm = bottomSheetView.findViewById<Button>(R.id.buttonConfirm)

        var selectedPlan: VisaPlan? = null

        recyclerView.adapter = VisaPlanAdapter(listOfPlans) { plan ->
            selectedPlan = plan
        }
        recyclerView.layoutManager = LinearLayoutManager(this)

        val dialog = BottomSheetDialog(this)
        dialog.setContentView(bottomSheetView)

        dialog.setOnShowListener {
            val bottomSheet =
                dialog.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
            bottomSheet?.let {
                val behavior = BottomSheetBehavior.from(it)
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        buttonConfirm.setOnClickListener {
            val plan = selectedPlan
            if (plan != null) {
                val transaction = Transaction(createVisaInstallmentParams(plan))
                submitTransaction(transaction)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Please select a plan", Toast.LENGTH_SHORT).show()
            }

        }

        dialog.show()
    }

    private fun createVisaInstallmentParams(visaPlan: VisaPlan): CardPaymentParams {
        val vPlanId = visaPlan.getvPlanID()
            ?: throw IllegalArgumentException("Visa Plan ID is null")
        val transactionId = installmentTransactionId
            ?: throw IllegalArgumentException("Installment Transaction ID is null")
        val version = visaPlan.termsAndConditions?.getOrNull(0)?.version?.toString()
            ?: throw IllegalArgumentException("Terms and Conditions version is null")

        val params = CardPaymentParams(
            checkoutId,
            "VISA",
            "4051 4601 2682 2028",
            "Jon Doe",
            "12",
            "2027",
            "270",
            vPlanId,
            version,
            transactionId
        )
        params.shopperResultUrl = getString(R.string.custom_ui_callback_scheme) + "://callback"
        return params
    }

    override fun paymentConfigRequestFailed(paymentError: PaymentError) {
        hideProgressBar()
        showErrorDialog(paymentError)
    }

    @ExperimentalCoroutinesApi
    override fun transactionCompleted(transaction: Transaction) {
        if (transaction.transactionType == TransactionType.SYNC) {
            // check the status of synchronous transaction
            requestPaymentStatus(resourcePath!!)
        } else {
            // open redirect url and wait for the final callback in the onNewIntent()
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(transaction.redirectUrl)))
        }
    }

    override fun transactionFailed(transaction: Transaction, paymentError: PaymentError) {
        hideProgressBar()
        showErrorDialog(paymentError)
    }

    private fun initViews() {
        binding.holderEditText.setText(Constants.Config.CARD_HOLDER_NAME)
        binding.numberEditText.setText(Constants.Config.CARD_NUMBER)
        binding.expiryMonthEditText.setText(Constants.Config.CARD_EXPIRY_MONTH)
        binding.expiryYearEditText.setText(Constants.Config.CARD_EXPIRY_YEAR)
        binding.cvvEditText.setText(Constants.Config.CARD_CVV)
        progressBar = binding.progressBarCustomUi

        binding.buttonPayNow.setOnClickListener {
            if (paymentProvider != null && checkFields()) {
                if (binding.switchVisaInstallment.isChecked) {
                    requestCheckoutId(
                        Constants.Config.EXTERNAL_MODE,
                        Constants.Config.VISA_INSTALLMENT_AMOUNT,
                        Constants.Config.VISA_INSTALLMENT_CURRENCY,
                        true
                    )
                } else {
                    requestCheckoutId()
                }
            }
        }

        binding.switchVisaInstallment.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                binding.numberEditText.setText(Constants.Config.VISA_INSTALLMENT_CARD_NUMBER)
                binding.expiryMonthEditText.setText(Constants.Config.VISA_INSTALLMENT_CARD_EXPIRY_MONTH)
                binding.expiryYearEditText.setText(Constants.Config.VISA_INSTALLMENT_CARD_EXPIRY_YEAR)
                binding.cvvEditText.setText(Constants.Config.VISA_INSTALLMENT_CARD_CVV)
            } else {
                binding.numberEditText.setText(Constants.Config.CARD_NUMBER)
                binding.expiryMonthEditText.setText(Constants.Config.CARD_EXPIRY_MONTH)
                binding.expiryYearEditText.setText(Constants.Config.CARD_EXPIRY_YEAR)
                binding.cvvEditText.setText(Constants.Config.CARD_CVV)
            }
        }
    }

    private fun checkFields(): Boolean {
        if (binding.holderEditText.text.isEmpty() ||
            binding.numberEditText.text.isEmpty() ||
            binding.expiryMonthEditText.text.isEmpty() ||
            binding.expiryYearEditText.text.isEmpty() ||
            binding.cvvEditText.text.isEmpty()) {
            showAlertDialog(R.string.error_empty_fields)

            return false
        }

        return true
    }

    private fun requestCheckoutInfo(checkoutId: String) {
        try {
            paymentProvider!!.requestCheckoutInfo(checkoutId, this)
        } catch (e: PaymentException) {
            e.message?.let { showAlertDialog(it) }
        }
    }

    private fun pay(checkoutId: String) {
        try {
            val paymentParams = createPaymentParams(checkoutId)
            paymentParams.shopperResultUrl =
                getString(R.string.custom_ui_callback_scheme) + "://callback"
            val transaction = Transaction(paymentParams)

            submitTransaction(transaction)
        } catch (e: PaymentException) {
            showErrorDialog(e.error)
        }
    }

    private fun createPaymentParams(checkoutId: String): CardPaymentParams {
        val cardHolder = binding.holderEditText.text.toString()
        val cardNumber = binding.numberEditText.text.toString()
        val cardExpiryMonth = binding.expiryMonthEditText.text.toString()
        val cardExpiryYear = binding.expiryYearEditText.text.toString()
        val cardCVV = binding.cvvEditText.text.toString()

        return CardPaymentParams(
                checkoutId,
                Constants.Config.CARD_BRAND,
                cardNumber,
                cardHolder,
                cardExpiryMonth,
                "20$cardExpiryYear",
                cardCVV
        )
    }

    private fun showConfirmationDialog(amount: String, currency: String) {
        AlertDialog.Builder(this)
                .setMessage(String.format(
                    getString(R.string.message_payment_confirmation), amount, currency))
                .setPositiveButton(R.string.button_ok) { _, _ -> pay(checkoutId) }
                .setNegativeButton(R.string.button_cancel) { _, _ -> hideProgressBar()}
                .setCancelable(false)
                .show()
    }

    private fun showErrorDialog(message: String) {
        runOnUiThread { showAlertDialog(message) }
    }

    private fun showErrorDialog(paymentError: PaymentError) {
        runOnUiThread { showErrorDialog(paymentError.errorMessage) }
    }

    private fun submitTransaction(transaction: Transaction) {
        paymentProvider?.let { provider ->
            if (binding.sendDeviceId.isChecked) {
                CyberSourceDeviceFingerprint(this).setDeviceFingerPrint(
                    transaction, provider, null,
                    FingerPrintListener { transactionResult: Transaction, error: PaymentError? ->
                        provider.submitTransaction(transactionResult, this)
                    })
            } else {
                provider.submitTransaction(transaction, this)
            }
        }
    }
}