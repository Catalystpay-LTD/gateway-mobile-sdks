package com.oppwa.mobile.connect.demo.receiver

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import com.oppwa.mobile.connect.checkout.meta.OnBeforeSubmitCallback
import com.oppwa.mobile.connect.checkout.meta.PaymentDetails
import com.oppwa.mobile.connect.demo.application.SampleApplication
import com.oppwa.mobile.connect.demo.common.Constants
import com.oppwa.mobile.connect.demo.common.Utils
import com.oppwa.mobile.connect.provider.model.BinInfo
import com.oppwa.msa.MerchantServerApplication
import com.oppwa.msa.model.response.CheckoutCreationResponse
import java.util.Optional

class CheckoutOnBeforeSubmitListener() : OnBeforeSubmitCallback {

    private lateinit var paymentDetails: PaymentDetails
    private lateinit var listener: OnBeforeSubmitCallback.Listener
    private lateinit var context: Context

    constructor(parcel: Parcel) : this() {
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
    }

    override fun onBeforeSubmit(paymentDetails: PaymentDetails, listener: OnBeforeSubmitCallback
        .Listener) {
        this.paymentDetails = paymentDetails
        this.listener = listener
        context = SampleApplication.getInstance().applicationContext

        val checkoutId = paymentDetails.checkoutId
        val paymentBrand = Optional.of(paymentDetails)
            .map { obj: PaymentDetails -> obj.paymentBrand }
            .orElse("")

        if (paymentDetails.selectedVisaInstallmentPlan != null &&
            paymentDetails.selectedVisaInstallmentPlan!!.isNotEmpty()) {
            // at this place merchant will get the selected visa installment plan
            // and can use it to show it in the confirmation screen before submitting the payment
            Log.d(Constants.LOG_TAG, paymentDetails.selectedVisaInstallmentPlan!!)

            // merchant can use callback.onComplete(paymentDetails) to continue to payment
            listener.onComplete(paymentDetails)
            return
        }

        if (isPaymentBrandWithExtraParams(paymentBrand)) {
            if ("AFTERPAY_PACIFIC" == paymentBrand) {
                requestCheckoutIdForAfterpay()
            }
        } else {
            resumeWorkflow(checkoutId)
        }
    }

    override fun onDetectedBin(p0: BinInfo) {

    }

    private fun isPaymentBrandWithExtraParams(paymentBrand: String?): Boolean {
        return "ONEY" == paymentBrand
                || "AFTERPAY_PACIFIC" == paymentBrand
    }

    // pay attention that we are using different amount and currency for ONEY and AFTERPAY_PACIFIC
    // for the new checkoutId, it is required due to external simulators which have specific configurations
    private fun requestCheckoutIdForAfterpay() {
        MerchantServerApplication.requestCheckoutId(
            MerchantServerApplication.getDefaultAuthorization(),
            Constants.Config.AFTERPAY_AMOUNT,
            Constants.Config.AFTERPAY_CURRENCY,
            "PA",
            getAfterpayExtraParameters(),
            this::handleCheckoutId
        )
    }

    private fun handleCheckoutId(
        response: CheckoutCreationResponse?,
        error: String?
    ) {
        if (error != null) {
            Log.e(Constants.LOG_TAG, error)
        }

        val checkoutId = Optional.ofNullable(response)
            .map { obj: CheckoutCreationResponse -> obj.ndc }
            .orElse(null)

        resumeWorkflow(checkoutId)
    }

    private fun getAfterpayExtraParameters(): Map<String, String> {
        val parameters: MutableMap<String, String> = HashMap()

        parameters["testMode"] = "EXTERNAL"
        parameters.putAll(
            Utils().getParametersFromFile(
                context, Constants.Config.AFTERPAY_PARAMETERS_FILE))

        return parameters
    }

    private fun resumeWorkflow(checkoutId: String?) {
        if (checkoutId != null) {
            paymentDetails.checkoutId = checkoutId
        }
        paymentDetails.let { listener.onComplete(it) }
    }

    companion object CREATOR : Parcelable.Creator<CheckoutOnBeforeSubmitListener> {
        override fun createFromParcel(parcel: Parcel): CheckoutOnBeforeSubmitListener {
            return CheckoutOnBeforeSubmitListener(parcel)
        }

        override fun newArray(size: Int): Array<CheckoutOnBeforeSubmitListener?> {
            return arrayOfNulls(size)
        }
    }
}