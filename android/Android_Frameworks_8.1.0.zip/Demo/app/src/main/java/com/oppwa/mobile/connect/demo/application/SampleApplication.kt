package com.oppwa.mobile.connect.demo.application

import android.app.Application

class SampleApplication : Application() {

    companion object {
        private var instance: SampleApplication? = null

        fun getInstance(): SampleApplication {
            return instance
                ?: throw IllegalStateException("SampleApplication not initialized yet!")
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}