package com.oppwa.mobile.connect.demo.activity

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.oppwa.mobile.connect.checkout.uicomponent.meta.UiComponentsConfig
import com.oppwa.mobile.connect.demo.R

import com.oppwa.mobile.connect.demo.common.Constants
import com.oppwa.msa.model.response.CheckoutCreationResponse
import com.oppwa.mobile.connect.demo.databinding.ActivityCheckoutUiBinding
import com.oppwa.mobile.connect.demo.uicomponent.CardUiComponentFragment
import com.oppwa.mobile.connect.demo.uicomponent.PaymentMethodSelectionUiComponentFragment
import com.oppwa.mobile.connect.demo.uicomponent.ProcessingUiComponentFragment

const val EXTRA_UI_COMPONENTS_ENABLED = "com.oppwa.mobile.connect.demo.activity.EXTRA_UI_COMPONENTS_ENABLED"


/**
 * Represents an activity for making payments via {@link CheckoutActivity}.
 */
class CheckoutUIActivity : BasePaymentActivity() {

    private lateinit var binding: ActivityCheckoutUiBinding
    private var configAmount: String? = null
    private var configCurrency: String? = null
    private var isInternalMode: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCheckoutUiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val amount = "${Constants.Config.AMOUNT} ${Constants.Config.CURRENCY}"

        binding.amountTextView.text = amount
        progressBar = binding.progressBarCheckoutUi

        binding.buttonProceedToCheckout.setOnClickListener {
            val testMode = if (isInternalMode) Constants.Config.INTERNAL_MODE
            else Constants.Config.EXTERNAL_MODE

            if (configCurrency == "SAR"){
                // this case is to simulate visa installment payment , when currency is SAR
                requestCheckoutId(testMode, configAmount, configCurrency, true)
            } else {
                requestCheckoutId(testMode, configAmount, configCurrency)
            }

        }

        binding.buttonConfigure.setOnClickListener{
            showConfigBottomSheet()
        }
    }

    override fun onCheckoutCreated(response: CheckoutCreationResponse?) {
        super.onCheckoutCreated(response)

        if (response?.ndc != null) {
            openCheckoutUI(response.ndc!!)
        }
    }

    private fun openCheckoutUI(checkoutId: String) {
        val checkoutSettings = createCheckoutSettings(checkoutId)

        if (intent.hasExtra(EXTRA_UI_COMPONENTS_ENABLED)) {
            checkoutSettings.uiComponentsConfig = getUiComponentsConfig()
        }

        // start the checkout activity
        checkoutLauncher.launch(checkoutSettings)
    }

    private fun getUiComponentsConfig(): UiComponentsConfig {
        return UiComponentsConfig.Builder()
            .setProcessingUiComponentClass(ProcessingUiComponentFragment::class.java)
            .setPaymentMethodSelectionUiComponentClass(
                PaymentMethodSelectionUiComponentFragment::class.java)
            .setCardUiComponentClass(CardUiComponentFragment::class.java)
            .build()
    }

    private fun showConfigBottomSheet() {
        val dialog = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_config, null)
        dialog.setContentView(view)

        val editTextAmount = view.findViewById<EditText>(R.id.editTextAmount)
        val editTextCurrency = view.findViewById<EditText>(R.id.editTextCurrency)
        val switchMode = view.findViewById<SwitchCompat>(R.id.switchMode)
        val buttonApply = view.findViewById<Button>(R.id.buttonApply)

        buttonApply.setOnClickListener {
            configAmount = editTextAmount.text.toString()
            configCurrency = editTextCurrency.text.toString()
            isInternalMode = !switchMode.isChecked // Assuming: unchecked = Internal, checked = External
            binding.amountTextView.text = "$configAmount $configCurrency"
            dialog.dismiss()
        }

        dialog.show()
    }
}