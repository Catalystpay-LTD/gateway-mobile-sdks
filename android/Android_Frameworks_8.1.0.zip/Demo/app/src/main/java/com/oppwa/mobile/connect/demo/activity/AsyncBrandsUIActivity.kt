package com.oppwa.mobile.connect.demo.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import com.oppwa.mobile.connect.checkout.dialog.CheckoutHelper
import com.oppwa.mobile.connect.checkout.meta.IdentificationDocType
import com.oppwa.mobile.connect.demo.R
import com.oppwa.mobile.connect.demo.common.Constants
import com.oppwa.mobile.connect.demo.common.Constants.Config.PAYTO_CURRENCY
import com.oppwa.mobile.connect.demo.common.Utils
import com.oppwa.mobile.connect.demo.databinding.ActivityAsyncBrandsUiBinding
import com.oppwa.mobile.connect.exception.PaymentError
import com.oppwa.mobile.connect.exception.PaymentException
import com.oppwa.mobile.connect.payment.CheckoutInfo
import com.oppwa.mobile.connect.payment.dlocal.OxxoVaPaymentParams
import com.oppwa.mobile.connect.payment.dlocal.PixVaPaymentParams
import com.oppwa.mobile.connect.payment.braintree.PaypalPayFastPaymentParams
import com.oppwa.mobile.connect.payment.braintree.PaypalPayfastConfig
import com.oppwa.mobile.connect.payment.braintree.VenmoPayFastPaymentParams
import com.oppwa.mobile.connect.payment.braintree.VenmoPayfastConfig
import com.oppwa.mobile.connect.payment.payto.PayToPaymentParams
import com.oppwa.mobile.connect.payment.processor.ProcessorActivityResult
import com.oppwa.mobile.connect.payment.processor.braintree.BraintreeProcessorResultContract
import com.oppwa.mobile.connect.payment.processor.payto.PayToProcessorResultContract
import com.oppwa.mobile.connect.payment.processor.paze.PazePaymentParams
import com.oppwa.mobile.connect.payment.processor.paze.PazeProcessorActivityResultContract
import com.oppwa.mobile.connect.provider.Connect
import com.oppwa.mobile.connect.provider.ITransactionListener
import com.oppwa.mobile.connect.provider.OppPaymentProvider
import com.oppwa.mobile.connect.provider.Transaction
import com.oppwa.mobile.connect.provider.TransactionType
import com.oppwa.msa.MerchantServerApplication
import com.oppwa.msa.model.response.CheckoutCreationResponse

/**
 * This activity represents the Async brands custom UI integration.
 */
class AsyncBrandsUIActivity : BasePaymentActivity(), ITransactionListener {

    private lateinit var binding: ActivityAsyncBrandsUiBinding

    private lateinit var checkoutId: String
    private lateinit var paymentProvider: OppPaymentProvider
    private var resourcePath: String? = null
    private var paymentBrand = ""

    private val payToLauncher =
        registerForActivityResult(PayToProcessorResultContract()) { processorActivityResult: ProcessorActivityResult ->
            handleTransactionLauncherResult(processorActivityResult)
        }

    private val pazeLauncher =
        registerForActivityResult(PazeProcessorActivityResultContract()) { processorActivityResult: ProcessorActivityResult ->
            handleTransactionLauncherResult(processorActivityResult)
        }

    private val braintreeLauncher = registerForActivityResult(
        BraintreeProcessorResultContract(),
        this::handleBraintreeLauncherResult
    )

    private fun handleBraintreeLauncherResult(processorActivityResult: ProcessorActivityResult) {

        if (processorActivityResult.paymentError != null) {
            hideProgressBar()
            showErrorDialog(processorActivityResult.paymentError!!)
        } else if (processorActivityResult.transaction != null) {
            paymentProvider.submitTransaction(processorActivityResult.transaction!!, this)
        } else {
            hideProgressBar()
            showAlertDialog(getString(R.string.error_message))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        resourcePath = savedInstanceState?.getString(STATE_RESOURCE_PATH)

        binding = ActivityAsyncBrandsUiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        paymentProvider = OppPaymentProvider(this, Connect.ProviderMode.TEST)
        paymentProvider.setThreeDSWorkflowListener { this }

        initViews()
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)

        outState.putString(STATE_RESOURCE_PATH, resourcePath)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        setIntent(intent)

        // check of the intent contains the callback scheme
        if (intent.scheme == getString(R.string.custom_ui_callback_scheme)) {
            requestPaymentStatus(resourcePath!!)
        }
    }

    private fun initViews() {
        progressBar = binding.progressBarCustomUi
        binding.buttonPayTo.setOnClickListener {
            paymentBrand = "PAYTO"
            requestCheckoutId(
                paymentBrand
            )
        }

        binding.buttonPaze.setOnClickListener {
            paymentBrand = "PAZE"
            requestCheckoutId(paymentBrand)
        }

        binding.buttonPix.setOnClickListener {
            paymentBrand = "PIX_VA"
            requestCheckoutId(paymentBrand)
        }

        binding.buttonOxxo.setOnClickListener {
            paymentBrand = "OXXO_VA"
            requestCheckoutId(paymentBrand)
        }

        binding.buttonPaypalPayfast.setOnClickListener {
            paymentBrand = "PAYPAL_PAYFAST"
            requestCheckoutId(paymentBrand)
        }

        binding.buttonVenmoPayfast.setOnClickListener {
            paymentBrand = "VENMO_PAYFAST"
            requestCheckoutId(paymentBrand)
        }
    }

    override fun onCheckoutCreated(response: CheckoutCreationResponse?) {
        super.onCheckoutCreated(response)

        response?.ndc.let {
            this.checkoutId = response?.ndc!!
            requestCheckoutInfo(checkoutId)
        }
    }

    override fun paymentConfigRequestSucceeded(checkoutInfo: CheckoutInfo) {
        // get the resource path from checkout info to request the payment status later
        resourcePath = checkoutInfo.resourcePath

        when (paymentBrand) {
            "PAYTO" -> {
                val paymentParams = PayToPaymentParams(
                    checkoutId,
                    "+61888888888", null, null, null
                )
                paymentParams.shopperResultUrl = CheckoutHelper.getShopperResultUrl()
                val transaction = Transaction(paymentParams)
                paymentProvider.submitTransaction(transaction, this)
            }
            "PAZE" -> {
                val params = PazePaymentParams(checkoutId)
                val transaction = Transaction(params)
                paymentProvider.submitTransaction(transaction, this)
            }
            "PIX_VA" ->{
                val params = PixVaPaymentParams(checkoutId, IdentificationDocType.TAXSTATEMENT ,
                    "00000000191")
                params.shopperResultUrl = CheckoutHelper.getShopperResultUrl()
                paymentProvider.submitTransaction(Transaction(params), this)
            }
            "OXXO_VA" ->{
                val params = OxxoVaPaymentParams(checkoutId, IdentificationDocType.TAXSTATEMENT ,
                    "00000000191")
                params.shopperResultUrl = CheckoutHelper.getShopperResultUrl()
                paymentProvider.submitTransaction(Transaction(params), this)
            }
            "PAYPAL_PAYFAST" -> {
                try {
                    val config = PaypalPayfastConfig(hasUserLocationConsent = false,
                        enableAppSwitch = false, appLinkReturnUrl = "https://docs.oppwa.com")
                    val paymentParams = PaypalPayFastPaymentParams(
                        checkoutId,
                        paymentProvider.providerMode, config
                    )
                    val transaction = Transaction(paymentParams)
                    braintreeLauncher.launch(transaction)
                } catch (e: PaymentException) {
                    Log.e("launchPaypalPayFast", "launchPaypalPayFast: " + e.error)
                }
            }
            "VENMO_PAYFAST" -> {
                try {
                    val config = VenmoPayfastConfig(appLinkReturnUrl = "https://docs.oppwa.com")
                    val paymentParams = VenmoPayFastPaymentParams(
                        checkoutId,
                        paymentProvider.providerMode, config
                    )
                    val transaction = Transaction(paymentParams)
                    braintreeLauncher.launch(transaction)
                } catch (e: PaymentException) {
                    Log.e("launchPaypalPayFast", "launchPaypalPayFast: " + e.error)
                }
            }
            else -> {
               Log.d("AsyncBrandsUIActivity", "Unsupported payment brand: $paymentBrand")
            }
        }
    }

    override fun paymentConfigRequestFailed(paymentError: PaymentError) {
        hideProgressBar()
        showErrorDialog(paymentError)
    }

    override fun transactionCompleted(transaction: Transaction) {
        when (paymentBrand) {
            "PAYTO" -> {
                payToLauncher.launch(transaction)
            }
            "PAZE" -> {
                pazeLauncher.launch(transaction)
            }
            else -> {
                if (transaction.transactionType == TransactionType.SYNC) {
                    // check the status of synchronous transaction
                    requestPaymentStatus(resourcePath!!)
                } else {
                    // open redirect url and wait for the final callback in the onNewIntent()
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(transaction.redirectUrl)))
                }
            }
        }
    }

    override fun transactionFailed(transaction: Transaction, paymentError: PaymentError) {
        hideProgressBar()
        showErrorDialog(paymentError)
    }

    private fun handleTransactionLauncherResult(processorActivityResult: ProcessorActivityResult) {
        hideProgressBar()
        when (paymentBrand) {
            "PAYTO" -> {
                if (resourcePath != null || processorActivityResult.paymentError != null) {
                    requestPaymentStatus(resourcePath!!)
                }
            }
            "PAZE" -> {
                if (processorActivityResult.paymentError != null) {
                    showErrorDialog(processorActivityResult.paymentError!!)
                } else {
                    requestPaymentStatus(resourcePath!!)
                }
            }
            "PIX_VA" -> {
                if (resourcePath != null || processorActivityResult.paymentError != null) {
                    requestPaymentStatus(resourcePath!!)
                }
            }
            "OXXO_VA" -> {
                if (resourcePath != null || processorActivityResult.paymentError != null) {
                    requestPaymentStatus(resourcePath!!)
                }
            }
        }
    }

    private fun requestCheckoutInfo(checkoutId: String) {
        try {
            paymentProvider.requestCheckoutInfo(checkoutId, this)
        } catch (e: PaymentException) {
            e.message?.let { showAlertDialog(it) }
        }
    }

    private fun showErrorDialog(message: String) {
        runOnUiThread { showAlertDialog(message) }
    }

    private fun showErrorDialog(paymentError: PaymentError) {
        runOnUiThread { showErrorDialog(paymentError.errorMessage) }
    }

    companion object {
        private const val STATE_RESOURCE_PATH = "STATE_RESOURCE_PATH"
    }

    protected fun requestCheckoutId(
        paymentBrand: String
    ) {
        showProgressBar()
        MerchantServerApplication.requestCheckoutId(
            MerchantServerApplication.getDefaultAuthorization(),
            getAmount(paymentBrand),
            getCurrency(paymentBrand),
            getPaymentType(paymentBrand),
            getExtraParameters(paymentBrand)
        ) { response, _ -> runOnUiThread { onCheckoutCreated(response) } }
    }

    private fun getAmount(paymentBrand: String): String {
        return when (paymentBrand) {
            "PAYTO" -> "36.25"
            "PAZE" -> "100.00"
            "PIX_VA" -> "100.00"
            "OXXO_VA" -> "100.00"
            "PAYPAL_PAYFAST" -> "11.00"
            "VENMO_PAYFAST" -> "9.00"
            else -> Constants.Config.AMOUNT
        }
    }

    private fun getCurrency(paymentBrand: String): String {
        return when (paymentBrand) {
            "PAYTO" -> PAYTO_CURRENCY
            "PAZE" -> "EUR"
            "PIX_VA" -> "BRL"
            "OXXO_VA" -> "MXN"
            "PAYPAL_PAYFAST", "VENMO_PAYFAST" -> "USD"
            else -> Constants.Config.CURRENCY
        }
    }

    private fun getPaymentType(paymentBrand: String): String {
        return when (paymentBrand) {
            "PAYTO" -> "DB"
            "PAZE" -> "DB"
            "PIX_VA" -> "DB"
            "OXXO_VA" -> "DB"
            else -> "PA"
        }
    }

    private fun getExtraParameters(paymentBrand: String): Map<String, String> {
        return when (paymentBrand) {
            "PAYTO" -> {
                val parameters: MutableMap<String, String> = HashMap()
                parameters["testMode"] = "EXTERNAL"
                parameters.putAll(
                    Utils().getParametersFromFile(
                        this, Constants.Config.PAYTO_PARAMETERS_FILE
                    )
                )
                parameters
            }

            "PAZE" -> {
                val parameters: MutableMap<String, String> = HashMap()
                parameters["testMode"] = "EXTERNAL"
                parameters.putAll(
                    Utils().getParametersFromFile(
                        this, Constants.Config.PAZE_PARAMETERS_FILE
                    )
                )
                parameters
            }
            "PIX_VA" -> {
                val parameters: MutableMap<String, String> = HashMap()
                parameters["testMode"] = "EXTERNAL"
                parameters.putAll(
                    Utils().getParametersFromFile(
                        this, Constants.Config.PIX_VA_PARAMETERS_FILE
                    )
                )
                parameters
            }

            "OXXO_VA" -> {
                val parameters: MutableMap<String, String> = HashMap()
                parameters["testMode"] = "EXTERNAL"
                parameters.putAll(
                    Utils().getParametersFromFile(
                        this, Constants.Config.OXXO_VA_PARAMETERS_FILE
                    )
                )
                parameters
            }

            "PAYPAL_PAYFAST", "VENMO_PAYFAST" -> {
                val parameters: MutableMap<String, String> = HashMap()
                parameters["testMode"] = "EXTERNAL"
                parameters.putAll(
                    Utils().getParametersFromFile(
                        this, Constants.Config.BRAINTREE_PARAMETERS_DATA_FILE_NAME
                    )
                )
                parameters
            }

            else -> emptyMap()
        }
    }
}