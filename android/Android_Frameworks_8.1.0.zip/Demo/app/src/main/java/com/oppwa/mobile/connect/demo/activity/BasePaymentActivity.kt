package com.oppwa.mobile.connect.demo.activity

import com.oppwa.mobile.connect.checkout.meta.CheckoutActivityResult
import com.oppwa.mobile.connect.checkout.meta.CheckoutActivityResultContract
import com.oppwa.mobile.connect.checkout.meta.CheckoutSettings
import com.oppwa.mobile.connect.checkout.meta.CheckoutSkipCVVMode
import com.oppwa.mobile.connect.demo.R
import com.oppwa.mobile.connect.demo.common.Constants
import com.oppwa.mobile.connect.demo.receiver.CheckoutOnBeforeSubmitListener
import com.oppwa.mobile.connect.provider.Connect
import com.oppwa.mobile.connect.utils.googlepay.CardPaymentMethodJsonBuilder
import com.oppwa.mobile.connect.utils.googlepay.PaymentDataRequestJsonBuilder
import com.oppwa.mobile.connect.utils.googlepay.TransactionInfoJsonBuilder
import com.oppwa.msa.MerchantServerApplication
import com.oppwa.msa.model.response.CheckoutCreationResponse
import com.oppwa.msa.model.response.PaymentStatusResponse
import org.json.JSONArray


/**
 * Represents a base activity for making the payments with mobile sdk.
 * This activity handles payment callbacks.
 */
open class BasePaymentActivity : BaseActivity() {

    protected val checkoutLauncher = registerForActivityResult(
            CheckoutActivityResultContract()) {
        result: CheckoutActivityResult -> this.handleCheckoutActivityResult(result)
    }

    private fun handleCheckoutActivityResult(result: CheckoutActivityResult) {
        hideProgressBar()

        if (result.isCanceled) {
            // checkout was cancelled by user
            return
        }

        // check the status of transaction
        requestPaymentStatus(result.resourcePath!!)
    }

    open fun onCheckoutCreated(response: CheckoutCreationResponse?) {
        if (response == null) {
            hideProgressBar()
            showAlertDialog(getString(R.string.error_message))
        }
    }

    protected fun requestCheckoutId(
        testMode: String? = null,
        amount: String? = null,
        currency: String? = null,
        isVisaInstallmentOn : Boolean = false
    ) {
        showProgressBar()
        val params = mutableMapOf<String, String>()
        if (testMode != null) {
            params["testMode"] = testMode
        }
        if (isVisaInstallmentOn) {
            params["customParameters[3DS2_enrolled]"] = "true"
        }
        MerchantServerApplication.requestCheckoutId(
            MerchantServerApplication.getDefaultAuthorization(),
            amount ?: Constants.Config.AMOUNT,
            currency ?: Constants.Config.CURRENCY,
            "PA",
            params
        ) { response, _ -> runOnUiThread { onCheckoutCreated(response) } }
    }



    protected fun requestPaymentStatus(resourcePath: String) {
        runOnUiThread {
            showProgressBar()
        }

        MerchantServerApplication.requestPaymentStatus(
            MerchantServerApplication.getDefaultAuthorization(),
            resourcePath
        ) { paymentStatusResponse, _ ->
            runOnUiThread {
                onPaymentStatusReceived(paymentStatusResponse)
            }
        }
    }

    protected fun createCheckoutSettings(checkoutId: String): CheckoutSettings {
        return CheckoutSettings(
            checkoutId, Constants.Config.PAYMENT_BRANDS,
            Connect.ProviderMode.TEST
        )
            .setSkipCVVMode(CheckoutSkipCVVMode.FOR_STORED_CARDS)
            .setGooglePayPaymentDataRequestJson(getGooglePayPaymentDataRequestJson())
            // setComponentName is deprecated way, use setOnBeforeSubmitCallback(),
            // if you want to receive callbacks from the checkout
            //.setComponentName(ComponentName(packageName, CheckoutBroadcastReceiver::class.java.name))
            .setOnBeforeSubmitCallback(CheckoutOnBeforeSubmitListener())
    }

    private fun onPaymentStatusReceived(paymentStatusResponse: PaymentStatusResponse?) {
        hideProgressBar()

        val message = if (MerchantServerApplication.isSuccessful(paymentStatusResponse))
            getString(R.string.message_successful_payment) else
                getString(R.string.message_unsuccessful_payment)

        showAlertDialog(message)
    }

    private fun getGooglePayPaymentDataRequestJson() : String {
        val allowedPaymentMethods = JSONArray()
                .put(CardPaymentMethodJsonBuilder()
                        .setAllowedAuthMethods(JSONArray()
                                .put("PAN_ONLY")
                                .put("CRYPTOGRAM_3DS")
                        )
                        .setAllowedCardNetworks(JSONArray()
                                .put("VISA")
                                .put("MASTERCARD")
                                .put("AMEX")
                                .put("DISCOVER")
                                .put("JCB")
                        )
                        .setGatewayMerchantId(Constants.MERCHANT_ID)
                        .toJson()
                )

        val transactionInfo = TransactionInfoJsonBuilder()
                .setCurrencyCode(Constants.Config.CURRENCY)
                .setTotalPriceStatus("FINAL")
                .setTotalPrice(Constants.Config.AMOUNT)
                .toJson()

        val paymentDataRequest = PaymentDataRequestJsonBuilder()
                .setAllowedPaymentMethods(allowedPaymentMethods)
                .setTransactionInfo(transactionInfo)
                .toJson()

        return paymentDataRequest.toString()
    }
}