package com.oppwa.mobile.connect.demo.common

object Constants {

    const val MERCHANT_ID = "ff80808138516ef4013852936ec200f2"
    const val LOG_TAG = "msdk.demo"

    // the configuration values to change across the app
    object Config {
        // the default amount and currency
        const val AMOUNT = "49.99"
        const val CURRENCY = "EUR"
        const val INTERNAL_MODE = "INTERNAL"
        const val EXTERNAL_MODE = "EXTERNAL"

        // the default amount and currency for AFTERPAY_PACIFIC
        const val AFTERPAY_AMOUNT = "108.50"
        const val AFTERPAY_CURRENCY = "USD"
        const val AFTERPAY_PARAMETERS_FILE = "afterpayPacificParameters.txt"
        const val PAYTO_PARAMETERS_FILE = "payToParameters.txt"
        const val PAZE_PARAMETERS_FILE = "pazeParameters.txt"
        const val PIX_VA_PARAMETERS_FILE = "pixvaParameters.txt"
        const val OXXO_VA_PARAMETERS_FILE = "oxxovaParameters.txt"
        const val BRAINTREE_PARAMETERS_DATA_FILE_NAME: String = "braintreePayfastParameters.txt"

        // the payment brands for Ready-to-Use UI and Payment Button
        val PAYMENT_BRANDS = linkedSetOf("VISA", "MASTER", "PAYPAL", "GOOGLEPAY","PAYTO","PAZE")

        // the default payment brand for payment button
        const val PAYMENT_BUTTON_BRAND = "MASTER"

        // the default payment brand for COPYandPAY in mSDK payment button
        const val COPY_AND_PAY_IN_MSDK_PAYMENT_BUTTON_BRAND = "AFTERPAY_PACIFIC"

        // the card info for SDK & Your Own UI
        const val CARD_BRAND = "VISA"
        const val CARD_HOLDER_NAME = "JOHN DOE"
        const val CARD_NUMBER = "4200000000000000"
        const val CARD_EXPIRY_MONTH = "07"
        const val CARD_EXPIRY_YEAR = "28"
        const val CARD_CVV = "123"

        // card info for Visa installments , SDK & Your Own UI
        const val VISA_INSTALLMENT_CARD_NUMBER = "4051460126822028"
        const val VISA_INSTALLMENT_CARD_EXPIRY_MONTH = "12"
        const val VISA_INSTALLMENT_CARD_EXPIRY_YEAR = "2027"
        const val VISA_INSTALLMENT_CARD_CVV = "270"
        const val VISA_INSTALLMENT_AMOUNT = "1100"
        const val VISA_INSTALLMENT_CURRENCY = "SAR"

        const val PAYTO_CURRENCY = "AUD"

    }
}