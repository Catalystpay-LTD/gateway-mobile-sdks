package com.oppwa.mobile.connect.demo.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.oppwa.mobile.connect.demo.R
import com.oppwa.mobile.connect.payment.visainstallment.VisaPlan

class VisaPlanAdapter(
    private val plans: List<VisaPlan>,
    private val onPlanSelected: (VisaPlan) -> Unit
) : RecyclerView.Adapter<VisaPlanAdapter.PlanViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION
    private var expandedPosition = RecyclerView.NO_POSITION

    inner class PlanViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvPerMonthCost: TextView = itemView.findViewById(R.id.tvPerMonthCost)
        val tvInstallmentNumber: TextView = itemView.findViewById(R.id.tvInstallmentNumber)
        val tvMonthlyRate: TextView = itemView.findViewById(R.id.tvMonthlyRate)
        val tvProcessingFees: TextView = itemView.findViewById(R.id.tvProcessingFees)
        val tvTerms: TextView = itemView.findViewById(R.id.tvTerms)

        init {
            itemView.setOnClickListener {
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    // Expand/collapse logic
                    val prevExpanded = expandedPosition
                    expandedPosition = if (expandedPosition == pos) RecyclerView.NO_POSITION else pos
                    notifyItemChanged(prevExpanded)
                    notifyItemChanged(pos)

                    selectedPosition = pos
                    notifyDataSetChanged()
                    onPlanSelected(plans[pos])
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_visa_plan, parent, false)
        return PlanViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {
        val plan = plans[position]
        holder.tvPerMonthCost.text = "${plan.costInfo?.currency.orEmpty()} " +
                "${plan.costInfo?.firstInstallment?.totalAmountExcludingUpfrontFee ?: ""}"
        holder.tvInstallmentNumber.text = "Installments: ${plan.numberOfInstallments ?: ""}"
        holder.tvMonthlyRate.text = "Monthly Rate: ${plan.costInfo?.annualPercentageRate ?: ""}%"
        holder.tvProcessingFees.text = "Processing Fees: ${plan.costInfo?.totalUpfrontFees ?: ""}"

        // Show terms only if expanded
        if (position == expandedPosition) {
            holder.tvTerms.visibility = View.VISIBLE
            holder.tvTerms.text = holder.itemView.context.getString(
                R.string.terms_and_conditions,
                plan.termsAndConditions?.getOrNull(0)?.text.orEmpty()
            )
        } else {
            holder.tvTerms.visibility = View.GONE
        }

        // Highlight selected item
        if (position == selectedPosition) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, android.R.color.darker_gray))
        } else {
            holder.itemView.setBackgroundColor(Color.TRANSPARENT)
        }
    }

    override fun getItemCount() = plans.size
}