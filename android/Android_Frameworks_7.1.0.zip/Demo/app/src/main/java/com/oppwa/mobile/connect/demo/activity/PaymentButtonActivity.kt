package com.oppwa.mobile.connect.demo.activity

import android.os.Bundle

import com.oppwa.mobile.connect.checkout.dialog.PaymentButtonFragment
import com.oppwa.mobile.connect.checkout.meta.WpwlOptions
import com.oppwa.mobile.connect.demo.R
import com.oppwa.mobile.connect.demo.common.Constants.Config.COPY_AND_PAY_IN_MSDK_PAYMENT_BUTTON_BRAND
import com.oppwa.mobile.connect.demo.databinding.ActivityPaymentButtonBinding
import com.oppwa.mobile.connect.exception.PaymentException
import com.oppwa.msa.model.response.CheckoutCreationResponse

const val EXTRA_AMOUNT = "com.oppwa.mobile.connect.demo.activity.EXTRA_AMOUNT"
const val EXTRA_CURRENCY = "com.oppwa.mobile.connect.demo.activity.EXTRA_CURRENCY"
const val EXTRA_PAYMENT_BRAND = "com.oppwa.mobile.connect.demo.activity.EXTRA_PAYMENT_BRAND"


/**
 * Represents an activity for making payments via {@link PaymentButtonSupportFragment}.
 */
class PaymentButtonActivity : BasePaymentActivity() {

    private lateinit var binding: ActivityPaymentButtonBinding
    private lateinit var paymentButtonFragment: PaymentButtonFragment
    private var paymentBrand: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPaymentButtonBinding.inflate(layoutInflater)
        setContentView(binding.root)

        paymentBrand = intent.getStringExtra(EXTRA_PAYMENT_BRAND)

        val amountText = "${intent.getStringExtra(EXTRA_AMOUNT)}" +
                " ${intent.getStringExtra(EXTRA_CURRENCY)}"
        binding.amountTextView.text = amountText

        progressBar = binding.progressBarPaymentButton

        addPaymentButton()
    }

    override fun onStart() {
        super.onStart()

        configurePaymentButton()
    }

    override fun onCheckoutCreated(response: CheckoutCreationResponse?) {
        super.onCheckoutCreated(response)

        pay(response?.ndc!!)
    }

    private fun addPaymentButton() {
        paymentButtonFragment = PaymentButtonFragment()

        supportFragmentManager
            .beginTransaction()
            .setReorderingAllowed(true)
            .add(R.id.payment_button_fragment_container, paymentButtonFragment)
            .commit()
    }

    private fun configurePaymentButton() {
        paymentButtonFragment.paymentBrand = paymentBrand
        paymentButtonFragment.paymentButton.apply {
            setOnClickListener {
                requestCheckoutId()
            }

            // customize the payment button (except Google Pay button)
            setBackgroundResource(R.drawable.drop_in_button_background)
        }
    }

    private fun pay(checkoutId: String) {
        val checkoutSettings = createCheckoutSettings(checkoutId)

        if (COPY_AND_PAY_IN_MSDK_PAYMENT_BUTTON_BRAND == paymentBrand) {
            checkoutSettings.wpwlOptions = prepareWpwlOptions()
        }

        try {
            paymentButtonFragment.setActivityResultLauncher(checkoutLauncher)
            paymentButtonFragment.submitTransaction(checkoutSettings)
        } catch (e: PaymentException) {
            showAlertDialog(R.string.error_message)
        }
    }

    private fun prepareWpwlOptions(): Map<String, WpwlOptions> {
        val wpwlOptionsMap: MutableMap<String, WpwlOptions> = HashMap()
        wpwlOptionsMap["AFTERPAY_PACIFIC"] = getAfterpayPacificWpwlOptions()
        return wpwlOptionsMap
    }

    private fun getAfterpayPacificWpwlOptions(): WpwlOptions {
        val wpwlOptions = WpwlOptions()
        wpwlOptions.addValue("inlineFlow", arrayOf("AFTERPAY_PACIFIC"))
        wpwlOptions.addJSFunction("onReady", "function()" +
                "{wpwl.executePayment(\"wpwl-container-virtualAccount-AFTERPAY_PACIFIC\")}")

        return wpwlOptions
    }
}