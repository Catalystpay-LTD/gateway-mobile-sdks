package com.oppwa.mobile.connect.demo.activity

import android.os.Bundle
import com.oppwa.mobile.connect.checkout.uicomponent.meta.UiComponentsConfig

import com.oppwa.mobile.connect.demo.common.Constants
import com.oppwa.msa.model.response.CheckoutCreationResponse
import com.oppwa.mobile.connect.demo.databinding.ActivityCheckoutUiBinding
import com.oppwa.mobile.connect.demo.uicomponent.CardUiComponentFragment
import com.oppwa.mobile.connect.demo.uicomponent.PaymentMethodSelectionUiComponentFragment
import com.oppwa.mobile.connect.demo.uicomponent.ProcessingUiComponentFragment

const val EXTRA_UI_COMPONENTS_ENABLED = "com.oppwa.mobile.connect.demo.activity.EXTRA_UI_COMPONENTS_ENABLED"


/**
 * Represents an activity for making payments via {@link CheckoutActivity}.
 */
class CheckoutUIActivity : BasePaymentActivity() {

    private lateinit var binding: ActivityCheckoutUiBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCheckoutUiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val amount = "${Constants.Config.AMOUNT} ${Constants.Config.CURRENCY}"

        binding.amountTextView.text = amount
        progressBar = binding.progressBarCheckoutUi

        binding.buttonProceedToCheckout.setOnClickListener {
            requestCheckoutId()
        }
    }

    override fun onCheckoutCreated(response: CheckoutCreationResponse?) {
        super.onCheckoutCreated(response)

        if (response?.ndc != null) {
            openCheckoutUI(response.ndc!!)
        }
    }

    private fun openCheckoutUI(checkoutId: String) {
        val checkoutSettings = createCheckoutSettings(checkoutId)

        if (intent.hasExtra(EXTRA_UI_COMPONENTS_ENABLED)) {
            checkoutSettings.uiComponentsConfig = getUiComponentsConfig()
        }

        // start the checkout activity
        checkoutLauncher.launch(checkoutSettings)
    }

    private fun getUiComponentsConfig(): UiComponentsConfig {
        return UiComponentsConfig.Builder()
            .setProcessingUiComponentClass(ProcessingUiComponentFragment::class.java)
            .setPaymentMethodSelectionUiComponentClass(
                PaymentMethodSelectionUiComponentFragment::class.java)
            .setCardUiComponentClass(CardUiComponentFragment::class.java)
            .build()
    }
}