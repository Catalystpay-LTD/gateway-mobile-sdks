package com.oppwa.mobile.connect.demo.uicomponent

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

import com.oppwa.mobile.connect.checkout.uicomponent.processing.ProcessingUiComponent
import com.oppwa.mobile.connect.checkout.uicomponent.processing.ProcessingUiComponentInteraction
import com.oppwa.mobile.connect.demo.databinding.ProcessingUiComponentFragmentBinding


class ProcessingUiComponentFragment: Fragment(), ProcessingUiComponent {

    private var _binding: ProcessingUiComponentFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = ProcessingUiComponentFragmentBinding.inflate(
            inflater, container, false)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    override fun onUiComponentCreated(interaction: ProcessingUiComponentInteraction) {
        // this method will be called after onViewCreated() and before onStart(),
        // it provides the link to the UI Component interaction, use it to initialize your UI
    }
}