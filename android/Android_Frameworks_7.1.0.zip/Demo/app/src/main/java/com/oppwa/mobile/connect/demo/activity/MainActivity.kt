package com.oppwa.mobile.connect.demo.activity

import android.content.Intent
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

import com.oppwa.mobile.connect.demo.R
import com.oppwa.mobile.connect.demo.common.Constants.Config.AFTERPAY_AMOUNT
import com.oppwa.mobile.connect.demo.common.Constants.Config.AFTERPAY_CURRENCY
import com.oppwa.mobile.connect.demo.common.Constants.Config.AMOUNT
import com.oppwa.mobile.connect.demo.common.Constants.Config.COPY_AND_PAY_IN_MSDK_PAYMENT_BUTTON_BRAND
import com.oppwa.mobile.connect.demo.common.Constants.Config.CURRENCY
import com.oppwa.mobile.connect.demo.common.Constants.Config.PAYMENT_BUTTON_BRAND
import com.oppwa.mobile.connect.demo.databinding.ActivityMainBinding
import com.oppwa.mobile.connect.provider.Connect


class MainActivity : AppCompatActivity() {

    private lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.checkoutUi.setOnClickListener {
            startActivity(Intent(this, CheckoutUIActivity::class.java)) }
        binding.paymentButton.setOnClickListener {
            startActivity(getPaymentButtonActivityIntent(PAYMENT_BUTTON_BRAND, CURRENCY, AMOUNT)) }
        binding.cnpInMsdkPaymentButton.setOnClickListener {
            startActivity(getPaymentButtonActivityIntent(
                COPY_AND_PAY_IN_MSDK_PAYMENT_BUTTON_BRAND, AFTERPAY_CURRENCY, AFTERPAY_AMOUNT)) }
        binding.customUi.setOnClickListener {
            startActivity(Intent(this, CustomUIActivity::class.java)) }
        binding.uiComponents.setOnClickListener {
            startActivity(Intent(this, CheckoutUIActivity::class.java)
                .putExtra(EXTRA_UI_COMPONENTS_ENABLED, true))
        }

        binding.versionNumber.text =
                String.format(getString(R.string.sdk_version_number), Connect.getVersion())
    }

    private fun getPaymentButtonActivityIntent(brand: String,
                                               currency: String,
                                               amount: String
    ) = Intent(this, PaymentButtonActivity::class.java)
        .putExtra(EXTRA_PAYMENT_BRAND, brand)
        .putExtra(EXTRA_CURRENCY, currency)
        .putExtra(EXTRA_AMOUNT, amount)
}