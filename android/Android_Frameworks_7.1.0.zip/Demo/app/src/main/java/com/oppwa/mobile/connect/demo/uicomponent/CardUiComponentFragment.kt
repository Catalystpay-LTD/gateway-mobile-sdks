package com.oppwa.mobile.connect.demo.uicomponent

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText

import androidx.fragment.app.Fragment

import com.oppwa.mobile.connect.checkout.uicomponent.card.CardUiComponent
import com.oppwa.mobile.connect.checkout.uicomponent.card.CardUiComponentInteraction
import com.oppwa.mobile.connect.demo.databinding.CardUiComponentFragmentBinding


class CardUiComponentFragment : Fragment(), CardUiComponent {

    private var _binding: CardUiComponentFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = CardUiComponentFragmentBinding.inflate(
            inflater, container, false)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    override fun onUiComponentCreated(interaction: CardUiComponentInteraction) {
        // this method will be called after onViewCreated() and before onStart(),
        // it provides the link to the UI Component interaction, use it to initialize your UI
        binding.payButton.setOnClickListener { interaction.submitPaymentDetails() }
    }

    override fun onInputValidation(editText: EditText, error: String?) {
        // use this callback to show or hide input validation errors
        editText.error = error
    }

    override fun onCardBrandDetection(cardBrands: MutableSet<String>) {
        // if multiple card brands are detected you can display them
        // and let shopper make a choice, the first detected brand will be set by default
    }

    override fun onCardBrandChange(cardBrand: String?) {
        // you can use this callback to display the card brand
    }

    override fun onViewVisibilityChange(view: View, visibility: Int) {
        // some views might be displayed or hidden depends on the card brand
        // or checkout settings, this callback provides the view and required visibility value
        view.visibility = visibility
    }

    override fun getCardNumberEditText(): EditText {
        return binding.cardNumber
    }

    override fun getCardHolderEditText(): EditText {
        return binding.cardHolder
    }

    override fun getCardExpiryDateEditText(): EditText {
        return binding.cardExpiryDate
    }

    override fun getCardSecurityCodeEditText(): EditText {
        return binding.cardSecurityCode
    }

    override fun getPhoneCountryCodeEditText(): EditText? {
        // some card brands require phone country code and number,
        // if you're going to use it, provide a link to the EditText for phone country code
        return null
    }

    override fun getPhoneNumberEditText(): EditText? {
        // some card brands require phone country code and number,
        // if you're going to use it, provide a link to the EditText for phone number
        return null
    }
}