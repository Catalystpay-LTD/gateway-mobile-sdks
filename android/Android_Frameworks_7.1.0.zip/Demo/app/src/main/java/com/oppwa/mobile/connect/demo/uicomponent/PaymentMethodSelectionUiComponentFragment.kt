package com.oppwa.mobile.connect.demo.uicomponent

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView

import com.oppwa.mobile.connect.checkout.meta.PaymentMethod
import com.oppwa.mobile.connect.checkout.uicomponent.paymentmethodselection.PaymentMethodSelectionUiComponent
import com.oppwa.mobile.connect.checkout.uicomponent.paymentmethodselection.PaymentMethodSelectionUiComponentInteraction
import com.oppwa.mobile.connect.demo.databinding.PaymentMethodListItemBinding
import com.oppwa.mobile.connect.demo.databinding.PaymentMethodSelectionUiComponentFragmentBinding


class PaymentMethodSelectionUiComponentFragment : Fragment(), PaymentMethodSelectionUiComponent {

    private var _binding: PaymentMethodSelectionUiComponentFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = PaymentMethodSelectionUiComponentFragmentBinding.inflate(
            inflater, container, false)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    override fun onUiComponentCreated(interaction: PaymentMethodSelectionUiComponentInteraction) {
        // this method will be called after onViewCreated() and before onStart(),
        // it provides the link to the UI Component interaction, use it to initialize your UI,
        // use interaction to get available payment methods.
        val paymentMethods = interaction.paymentMethods
        val adapter = PaymentMethodAdapter(paymentMethods) {
            // use interaction to select payment method
            position -> interaction.onPaymentMethodSelected(paymentMethods[position])
        }

        binding.paymentMethodRecyclerView.adapter = adapter
    }

    class PaymentMethodAdapter(private val paymentMethods: Array<PaymentMethod>,
                               private val listener: OnItemClickListener) :
        RecyclerView.Adapter<PaymentMethodAdapter.ViewHolder>() {

        fun interface OnItemClickListener {

            fun onItemClick(position: Int)
        }

        class ViewHolder(val binding: PaymentMethodListItemBinding, listener: OnItemClickListener) :
            RecyclerView.ViewHolder(binding.root) {

            init {
                itemView.setOnClickListener {
                    val position = adapterPosition

                    if (position != RecyclerView.NO_POSITION) listener.onItemClick(position)
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = PaymentMethodListItemBinding.inflate(
                LayoutInflater.from(parent.context), parent, false)

            return ViewHolder(binding, listener)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.binding.paymentMethodName.text = paymentMethods[position].displayableName
        }

        override fun getItemCount() = paymentMethods.size
    }
}