Before running the application, make sure the libraries files are copied to the following folders:

oppwa.mobile:
Remove the version number and copy 'oppwa.mobile.aar' to the 'oppwa.mobile' folder.